-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 30, 2021 at 10:02 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `email`, `password`) VALUES
(1, 'sunnygkp10@gmail.com', '123456'),
(2, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `qid` text NOT NULL,
  `ansid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`qid`, `ansid`) VALUES
('60dc1e688ba74', '60dc1e6894ee6'),
('60dc1e692463d', '60dc1e6924a25'),
('60dc1e6978228', '60dc1e69789f8'),
('60dc1e6a140ba', '60dc1e6a14c72'),
('60dc1e6a553c1', '60dc1e6a56361'),
('60dc1e6b16bec', '60dc1e6b173bc'),
('60dc1e6bd33b8', '60dc1e6bd4358'),
('60dc1e6c9d0b4', '60dc1e6c9d49d'),
('60dc1e6cef918', '60dc1e6cf08b8'),
('60dc1e6dc0b46', '60dc1e6dc16fe'),
('60dc21256f994', '60dc212585159'),
('60dc2125e73c0', '60dc2125eecda');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` text NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `feedback` varchar(500) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `email` varchar(50) NOT NULL,
  `eid` text NOT NULL,
  `score` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`email`, `eid`, `score`, `level`, `sahi`, `wrong`, `date`) VALUES
('hi@gmail.com', '60dc20969fa74', 1, 2, 1, 1, '2021-06-30 07:46:23');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `qid` varchar(50) NOT NULL,
  `option` varchar(5000) NOT NULL,
  `optionid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`qid`, `option`, `optionid`) VALUES
('60dc1e688ba74', 'largest railway station', '60dc1e6894ee6'),
('60dc1e688ba74', 'highest railway station', '60dc1e68952ce'),
('60dc1e688ba74', 'second', '60dc1e68956b6'),
('60dc1e688ba74', 'new', '60dc1e6895a9e'),
('60dc1e692463d', 'largest railway station', '60dc1e6924a25'),
('60dc1e692463d', 'highest railway station', '60dc1e6924e0d'),
('60dc1e692463d', 'highest railway station', '60dc1e69251f5'),
('60dc1e692463d', 'new', '60dc1e69255dd'),
('60dc1e6978228', 'new', '60dc1e6978610'),
('60dc1e6978228', 'largest railway station', '60dc1e69789f8'),
('60dc1e6978228', 'highest railway station', '60dc1e6978de0'),
('60dc1e6978228', 'highest railway station', '60dc1e69791c8'),
('60dc1e6a140ba', 'highest railway station', '60dc1e6a144a2'),
('60dc1e6a140ba', 'highest railway station', '60dc1e6a1488a'),
('60dc1e6a140ba', 'largest railway station', '60dc1e6a14c72'),
('60dc1e6a140ba', 'new', '60dc1e6a1505a'),
('60dc1e6a553c1', 'highest railway station', '60dc1e6a557a9'),
('60dc1e6a553c1', 'new', '60dc1e6a55b91'),
('60dc1e6a553c1', 'highest railway station', '60dc1e6a55f79'),
('60dc1e6a553c1', 'largest railway station', '60dc1e6a56361'),
('60dc1e6b16bec', 'highest railway station', '60dc1e6b16fd4'),
('60dc1e6b16bec', 'largest railway station', '60dc1e6b173bc'),
('60dc1e6b16bec', 'highest railway station', '60dc1e6b177a4'),
('60dc1e6b16bec', 'new', '60dc1e6b17b8c'),
('60dc1e6bd33b8', 'highest railway station', '60dc1e6bd37a0'),
('60dc1e6bd33b8', 'highest railway station', '60dc1e6bd3b88'),
('60dc1e6bd33b8', 'new', '60dc1e6bd3f70'),
('60dc1e6bd33b8', 'largest railway station', '60dc1e6bd4358'),
('60dc1e6c9d0b4', 'largest railway station', '60dc1e6c9d49d'),
('60dc1e6c9d0b4', 'new', '60dc1e6c9d885'),
('60dc1e6c9d0b4', 'highest railway station', '60dc1e6c9dc6d'),
('60dc1e6c9d0b4', 'highest railway station', '60dc1e6c9e055'),
('60dc1e6cef918', 'new', '60dc1e6cefd00'),
('60dc1e6cef918', 'highest railway station', '60dc1e6cf00e8'),
('60dc1e6cef918', 'highest railway station', '60dc1e6cf04d0'),
('60dc1e6cef918', 'largest railway station', '60dc1e6cf08b8'),
('60dc1e6dc0b46', 'new', '60dc1e6dc0f2e'),
('60dc1e6dc0b46', 'highest railway station', '60dc1e6dc1316'),
('60dc1e6dc0b46', 'largest railway station', '60dc1e6dc16fe'),
('60dc1e6dc0b46', 'highest railway station', '60dc1e6dc1ae6'),
('60dc21256f994', '120 metres', '60dc2125845a1'),
('60dc21256f994', '125 metres', '60dc212584989'),
('60dc21256f994', '128 metres', '60dc212584d71'),
('60dc21256f994', '150 metres', '60dc212585159'),
('60dc2125e73c0', '45 km/hr', '60dc2125ee50a'),
('60dc2125e73c0', '45 km/hr', '60dc2125ee8f2'),
('60dc2125e73c0', '45 km/hr', '60dc2125eecda'),
('60dc2125e73c0', '45 km/hr', '60dc2125ef0c2');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `eid` text NOT NULL,
  `qid` text NOT NULL,
  `qns` text NOT NULL,
  `choice` int(10) NOT NULL,
  `sn` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`eid`, `qid`, `qns`, `choice`, `sn`) VALUES
('60dc20969fa74', '60dc21256f994', 'A train running at the speed of 60 km/hr crosses a pole in 9 seconds. What is the length of the train?', 4, 1),
('60dc20969fa74', '60dc2125e73c0', 'A train 125 m long passes a man, running at 5 km/hr in the same direction in which the train is going, in 10 seconds. The speed of the train is:', 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `eid` text NOT NULL,
  `title` varchar(100) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `time` bigint(20) NOT NULL,
  `intro` text NOT NULL,
  `tag` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`eid`, `title`, `sahi`, `wrong`, `total`, `time`, `intro`, `tag`, `date`) VALUES
('60dc20969fa74', 'Test', 2, 1, 2, 2, 'this is test', 'test', '2021-06-30 07:43:18');

-- --------------------------------------------------------

--
-- Table structure for table `rank`
--

CREATE TABLE `rank` (
  `email` varchar(50) NOT NULL,
  `score` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rank`
--

INSERT INTO `rank` (`email`, `score`, `time`) VALUES
('hi@gmail.com', 1, '2021-06-30 07:46:23');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(50) NOT NULL,
  `gender` varchar(5) NOT NULL,
  `college` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mob` bigint(20) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `gender`, `college`, `email`, `mob`, `password`) VALUES
('Rahul', 'M', 'cu', 'hi@gmail.com', 7854124578, '91d5181d621bd9838b00655d29f0577d');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
